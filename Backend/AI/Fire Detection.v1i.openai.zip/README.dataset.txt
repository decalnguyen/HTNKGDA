# Fire Detection > 2022-08-29 4:48pm
https://universe.roboflow.com/fire-dataset-tp9jt/fire-detection-sejra

Provided by a Roboflow user
License: CC BY 4.0

